import {polyhedronPixelPicker} from './polyhedron-pixel-picker.ts';
import type{SurfacePosition}from'../surfaces/contracts.ts';import type{SpiralGeometry}from'../surfaces/spiral.ts';
import{prismLayout,unprojectPrism,navigatePrism}from'./prismatic-view.ts';
import type{CylinderView,CylinderViewport,CylinderScreenPoint}from'./cylindrical-view.ts';import type{PolyhedronProjection}from'./polyhedron-projection.ts';
export{initialPrismView as initialSpiralView,prismRay as spiralRay,prismVisible as spiralVisible,prismIndexVisible as spiralIndexVisible}from'./prismatic-view.ts';
/** Recognizable upper/underside footprints and bounded genuine perimeter rows.
 * Row cuts do not change physical connectivity or intrinsic brush distances. */
const dimensions=new WeakMap<SpiralGeometry,{capOffset:number;rowHeight:number;wallTop:number;rows:number;width:number}>();
export function spiralMapDimensions(g:SpiralGeometry){let d=dimensions.get(g);if(!d){const extent=Math.max(...g.outline.map(p=>Math.abs(p[1])))/g.scaleMeters,capOffset=extent+.35,rowHeight=g.metadata.thicknessMeters/g.scaleMeters+.3,wallTop=-2*extent-1.0,rows=Math.ceil(g.outline.length/16),width=Math.max(...Array.from({length:rows},(_,row)=>(g.perimeterOffsets[Math.min(g.outline.length,(row+1)*16)]!-g.perimeterOffsets[row*16]!)/g.scaleMeters));d={capOffset,rowHeight,wallTop,rows,width};dimensions.set(g,d);}return d;}
export function spiralNetPoint(g:SpiralGeometry,p:SurfacePosition):readonly[number,number]{const q=g.normalize(p),P=g.referencePosition(q),region=g.region(q.patchId),R=g.scaleMeters,d=spiralMapDimensions(g);if(region==='upper'||region==='lower')return[P[0]/R,P[2]/R+(region==='upper'?d.capOffset:-d.capOffset)];const edge=Number(g.physicalFaceId(q.patchId).slice(5)),row=Math.floor(edge/16),A=g.outline[edge]!,B=g.outline[(edge+1)%g.outline.length]!,length=Math.hypot(B[0]-A[0],B[1]-A[1]),along=((P[0]-A[0])*(B[0]-A[0])+(P[2]-A[1])*(B[1]-A[1]))/length,start=g.perimeterOffsets[row*16]!,end=g.perimeterOffsets[Math.min(g.outline.length,(row+1)*16)]!;return[(g.perimeterOffsets[edge]!+along-(start+end)/2)/R,d.wallTop-row*d.rowHeight+P[1]/R];}
const maps=new WeakMap<SpiralGeometry,{minX:number;maxX:number;minY:number;maxY:number}>();
function mapBounds(g:SpiralGeometry){let b=maps.get(g);if(!b){let minX=Infinity,maxX=-Infinity,minY=Infinity,maxY=-Infinity;for(const patchId of g.faces)for(const[u,v]of[[0,0],[1,0],[0,1]]){const p=spiralNetPoint(g,{...g.identity,patchId,u:u!,v:v!});minX=Math.min(minX,p[0]);maxX=Math.max(maxX,p[0]);minY=Math.min(minY,p[1]);maxY=Math.max(maxY,p[1]);}b={minX,maxX,minY,maxY};maps.set(g,b);}return b;}
const layouts=new WeakMap<SpiralGeometry,{view:CylinderView;width:number;height:number;layout:{x:number;y:number;scale:number}}>();
function calculateLayout(g:SpiralGeometry,v:CylinderView,size:CylinderViewport){if(v.mode==='physical')return prismLayout(g,v,size);const b=mapBounds(g),d=spiralMapDimensions(g),hx=v.phase===1?Math.max(...g.outline.map(p=>Math.abs(p[0])))/g.scaleMeters:v.phase===2?d.width/2:Math.max(Math.abs(b.minX),Math.abs(b.maxX)),hy=v.phase===1?d.capOffset-.35:v.phase===2?(d.rows*d.rowHeight)/2:Math.max(Math.abs(b.minY),Math.abs(b.maxY));return{x:size.width/2,y:size.height/2,scale:Math.min(size.width*.84/(2*hx),size.height*.70/(2*hy))*v.zoom};}
export function spiralLayout(g:SpiralGeometry,v:CylinderView,size:CylinderViewport){const cached=layouts.get(g);if(cached?.view===v&&cached.width===size.width&&cached.height===size.height)return cached.layout;const layout=calculateLayout(g,v,size);layouts.set(g,{view:v,width:size.width,height:size.height,layout});return layout;}
export function projectSpiral(g:SpiralGeometry,p:SurfacePosition,v:CylinderView,size:CylinderViewport){if(v.mode==='physical'){const P=g.referencePosition(p).map((x,k)=>x/g.scaleMeters-v.target[k]!),l=spiralLayout(g,v,size),dot=(b:readonly number[])=>P.reduce((s,x,k)=>s+x*b[k]!,0);return{x:l.x+dot(v.frame.right)*l.scale,y:l.y-dot(v.frame.up)*l.scale};}const a=spiralNetPoint(g,p),l=spiralLayout(g,v,size);return{x:l.x+(a[0]+v.pan.x)*l.scale,y:l.y-(a[1]+v.pan.y)*l.scale};}
export function unprojectSpiral(g:SpiralGeometry,v:CylinderView,size:CylinderViewport,p:CylinderScreenPoint){if(v.mode==='physical')return unprojectPrism(g,v,size,p);const l=spiralLayout(g,v,size),X=(p.x-l.x)/l.scale-v.pan.x,Y=(l.y-p.y)/l.scale-v.pan.y;for(const patchId of g.faces){const a=spiralNetPoint(g,{...g.identity,patchId,u:0,v:0}),b=spiralNetPoint(g,{...g.identity,patchId,u:1,v:0}),c=spiralNetPoint(g,{...g.identity,patchId,u:0,v:1}),ux=b[0]-a[0],uy=b[1]-a[1],vx=c[0]-a[0],vy=c[1]-a[1],det=ux*vy-uy*vx;let u=((X-a[0])*vy-(Y-a[1])*vx)/det,w=(ux*(Y-a[1])-uy*(X-a[0]))/det;if(![u,w].every(Number.isFinite)||u< -1e-9||w< -1e-9||u+w>1+1e-9)continue;u=Math.max(0,Math.min(1,u));w=Math.max(0,Math.min(1,w));if(u+w>1)w=1-u;return g.normalize({...g.identity,patchId,u,v:w});}}
export function navigateSpiral(g:SpiralGeometry,v:CylinderView,dx:number,dy:number,size:CylinderViewport,pan=false){if(v.mode==='physical')return navigatePrism(g,v,dx,dy,size,pan);const l=spiralLayout(g,v,size);return{...v,pan:{x:v.pan.x+dx/l.scale,y:v.pan.y-dy/l.scale}};}
export const SPIRAL_PROJECTION:PolyhedronProjection<SpiralGeometry>={layout:spiralLayout,netPoint:spiralNetPoint,project:projectSpiral,unproject:unprojectSpiral};

/** Exact nearest-triangle quarter rays in 32px geometry-only bins. Same
 * accepted axial mechanism; actual Spiral projection and topology specialize it. */
export function spiralPixelPicker(g:SpiralGeometry,v:CylinderView,size:CylinderViewport,width:number,height:number){return polyhedronPixelPicker(g,v,size,width,height,projectSpiral);}

/** Actual concave cap outline / contiguous wall-run silhouettes, without
 * internal atlas edges. No hull, expanded material or hidden backing surface. */
export function spiralGroupContours(g:SpiralGeometry,group:readonly string[],view:CylinderView,size:CylinderViewport){
 const contours:{x:number;y:number}[][]=[],M=g.outline.length;
 const vertex=(id:number,physical:string)=>{const p=g.positionsFromWeights(new Map([[id,1]])).find(p=>g.physicalFaceId(p.patchId)===physical)!;return projectSpiral(g,p,view,size);};
 const cap=(prefix:string,offset:number)=>g.outline.map((_,i)=>{const p=g.positionsFromWeights(new Map([[i+offset,1]])).find(p=>p.patchId.startsWith(prefix))!;return projectSpiral(g,p,view,size);});
 if(view.mode==='map'){
  contours.push(cap('upper-',0),cap('lower-',M));
  for(let start=0;start<M;start+=16){const end=Math.min(M,start+16),last=end-1,right=end%M;contours.push([vertex(start,`wall-${start}`),vertex(right,`wall-${last}`),vertex(right+M,`wall-${last}`),vertex(start+M,`wall-${start}`)]);}
 }else if(group[0]?.startsWith('upper-'))contours.push(cap('upper-',0));
 else if(group[0]?.startsWith('lower-'))contours.push(cap('lower-',M));
 else if(group.length){const edges=group.map(id=>Number(id.slice(5))),start=edges[0]!,upper=[vertex(start,`wall-${start}`),...edges.map(i=>vertex((i+1)%M,`wall-${i}`))],lower=[...edges.toReversed().map(i=>vertex((i+1)%M+M,`wall-${i}`)),vertex(start+M,`wall-${start}`)];contours.push([...upper,...lower]);}
 return contours;
}
