﻿import subprocess,json
from pathlib import Path
keywords=['flat-ring','flat-disc','open-cylinder','ringworld','cylindrical','connected-worker-reuse']
files=sorted(str(p).replace('\\','/') for p in Path('src').rglob('*.test.ts') if any(k in p.name for k in keywords))
commands=[('source',['node','--test','--test-concurrency=1',*files]),('equivalence',['node','.local/compare-ring-distance.ts']),('typecheck',['node','node_modules/typescript/bin/tsc','--noEmit']),('build',['node','node_modules/vite/bin/vite.js','build'])]
meta=[]
for name,command in commands:
 log=Path('.local')/f'flat-ring-c-final-{name}.log'
 with log.open('w',encoding='utf-8') as f:
  f.write('Command: '+json.dumps(command)+'\n');f.flush()
  p=subprocess.Popen(command,stdout=f,stderr=subprocess.STDOUT,creationflags=subprocess.BELOW_NORMAL_PRIORITY_CLASS)
  code=p.wait();f.write('\nExit code: '+str(code)+'\n')
 meta.append({'name':name,'command':command,'exitCode':code,'log':str(log).replace('\\','/')})
 print(name,'exit',code,flush=True)
 if code:break
Path('.local/flat-ring-c-final-checks.json').write_text(json.dumps(meta,indent=2)+'\n')
raise SystemExit(code)
