﻿import subprocess,json
from pathlib import Path
files=['src/surfaces/ribbon.test.ts','src/terrain/ribbon.test.ts','src/editor/ribbon-configuration.test.ts','src/surfaces/polyhedron-local-domain.test.ts','src/surfaces/pyramid-path.test.ts','src/surfaces/tetrahedron.test.ts','src/surfaces/octahedron.test.ts','src/surfaces/spiral-local-certificates.test.ts','src/surfaces/spiral-pruned-routes.test.ts']
commands=[('source',['node','--test','--test-concurrency=1',*files]),('typecheck',['node','node_modules/typescript/bin/tsc','--noEmit']),('build',['node','node_modules/vite/bin/vite.js','build'])]
for name,command in commands:
 with Path('.local/ribbon-a-'+name+'.log').open('w',encoding='utf-8') as f:
  f.write('Command: '+json.dumps(command)+'\n');f.flush();p=subprocess.Popen(command,stdout=f,stderr=subprocess.STDOUT,creationflags=subprocess.BELOW_NORMAL_PRIORITY_CLASS);code=p.wait();f.write('\nExit code: '+str(code)+'\n')
 print(name,code,flush=True)
 if code:break
raise SystemExit(code)
