﻿import {createRibbonTerrain}from'../src/terrain/ribbon.ts';import{RIBBON_DEFAULT_DIMENSIONS,RIBBON_PRESETS}from'../src/surfaces/ribbon.ts';import{ribbonBrushPolicy,RIBBON_DAB_ADAPTER}from'../src/terrain/ribbon-brush.ts';import{ribbonDistance,ribbonDistanceResources}from'../src/surfaces/ribbon-distance.ts';
const t=createRibbonTerrain({terrainId:'t',geometry:{...RIBBON_DEFAULT_DIMENSIONS,...RIBBON_PRESETS.Wide,provider:'physical-faceted-ribbon',version:1,role:'exterior',identity:{worldId:'w',surfaceId:'s'}},detail:128}),g=t.geometry,policy=ribbonBrushPolicy(t),p={...g.identity,patchId:'second-face-12-0:0',u:0,v:0},radius=policy.maximum*.999,plan=RIBBON_DAB_ADAPTER.candidates(t,p,radius);
for(const s of plan.samples())if(plan.chordLowerBound(s.position)<radius){try{ribbonDistance(g,p,s.position,{absoluteToleranceMeters:radius*1e-6,reachMeters:policy.maximum});}catch(e){console.log(JSON.stringify((e as Error).cause,null,2));break;}}

console.log(ribbonDistanceResources(g));
