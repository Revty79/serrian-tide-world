# Atlas rendering and shared editor standard

Owner direction, 2026-10-22: **Use what works. Reinvent only when proven
unworkable.** This is a standing requirement for every subsequent Atlas shape.
It supplements the current hollow-world correction and Open Cylinder work;
it does not authorize additional shapes or a replacement terrain engine.

The owner's 2026-10-23 [course correction](ATLAS-PHASE2-COURSE-CORRECTION.md)
supersedes historical deferrals of basic holes, tunnels and reciprocal links.
A completed applicable 3D editor includes their real material validation,
physical subtraction, shared authoring/history and strict Save/Open, alongside
responsive terrain and sharp presentation. Preserve supported 0 m reference-
ground restrictions; advanced displaced excavation and the full Tunnel Network
Designer remain later systems. A blocked geometry must not hold up independent
finishing or geometry work. Older checkpoint reviews describe their historical
capabilities rather than granting an ongoing deferral.

Atlas is one editor. New geometry inherits the accepted presentation, input,
camera interaction, numerical editing, scheduling, history, persistence and
workspace behavior wherever those implementations remain valid. Demonstrate a
specific incompatibility before replacing an accepted mechanism. Extract shared
infrastructure incrementally; keep the accepted solid renderers operational.

The owner accepted the specific painted-coastline correction after identifying
the 0 m versus -100 m initialization difference in matched captures. Normal new
hollow worlds now default to the same **-100 m blank ocean** as solids. The
explicit **Reference shell (0 m)** option preserves level-shell hole/tunnel
authoring. This later direct authorization covers new-world initialization; it
does not authorize modifying an existing map's heights or reinterpreting saves.
Thin shells that cannot safely contain a -100 m ocean require the explicit
reference-shell option or larger clearance; never clamp elevations silently.

## Existing reference implementations

| Family | Accepted terrain presentation, reused by solid and hollow | Geometry adapters |
| --- | --- | --- |
| Cylinder | `cylindrical-elevation.ts`: shape-preserving numerical Hermite reconstruction and interpolated physical gradients. `cylindrical-raster.ts`: coherent terrain epochs, palette, relief, coastline coverage and Canvas output. `cylindrical-webgl.ts`: the same field/color functions in both programs. | Wall/disk chart coordinates, physical normals, fitted projection and camera rays; `hollow-cylinder-display.ts` supplies actual excavation intersections. |
| Open Cylinder | The actual accepted cylinder Hermite, coherent raster/cache, field/color/coast GLSL, GPU resources, backing/refinement policy and editor session/workspace are shared. See `ConnectedWorkspace`, `ConnectedPreviewSession`, `coherent-terrain-raster.ts` and `cylindrical-terrain-glsl.ts`. | Four real annular patches, shared crease ownership, inner-wall/rim row orientation, fitted inversion, actual open-volume rays and protected reference-shell excavation. No filled disk caps or fabricated closed-worker metadata. |
| Sphere | `spherical-elevation.ts`: canonical alias-aware height/gradient field and shared terrain color pass. `spherical-field-raster.ts`: common Globe/net raster and coast coverage. `spherical-webgl.ts`: shared field and terrain shading. | Cube-sphere chart lookup, projection, cavity rays and shell/capsule subtraction. |
| Cube | `solid-cube-field.ts`: canonical bilinear elevation/gradient sampling and terrain color. `solid-cube-canvas.ts`: accepted face atlas and its ordinary presentation. `solid-cube-webgl.ts`: accepted field, palette, oriented relief and four-ray terrain presentation. | Face projection, normals, joins and box/capsule subtraction. Physical cut regions extend the accepted face presentation. |
| Solid and Hollow Pyramid | The same `polyhedralDisplayColor` extracted from the accepted cube color pass, unchanged cube GLSL palette/relief functions, four-ray GPU coverage, sharp face atlases, indexed display epochs and shared graphics/backing policy. Both variants use `PyramidDisplayCache` and `PyramidPresentation`. | Four real triangles and a square base, barycentric field addresses, five-plane picking, physical frames and cavity perspective. Canvas cavity inspection samples that same atlas through exact inverse plane homographies; no alternate terrain or smoothing pass. |
| Solid and Hollow Regular Tetrahedron | The same generic polyhedral display cache, palette/relief, sharp atlas, incremental epochs, four-ray GPU and graphics/backing mechanisms used by Pyramid. `PolyhedronPresentation` accepts real face count/triangle flags and a geometry projection; Pyramid keeps its compatibility entry points. | Four real equilateral triangles including the base, canonical edge/vertex ownership, true normals, four-plane picking and a connected triangular net. Nested hollow banks use this identical field and presenter with inward physical normals, fitted inside editing and center-cavity projection. See the [solid](TETRAHEDRON-SOLID-EDITOR.md) and [hollow](TETRAHEDRON-HOLLOW-EDITOR.md) operational reviews. |

The physical Torus reuses the Cylinder Hermite field, palette/relief, coherent
raster, merged periodic dirty regions and ConnectedWorkspace input/history and
refinement policies. Its adapter supplies real Torus rays, normals, both periodic
addresses and metric gradients. N128/N256 use 4N by N canonical samples; no common
work, backing or history cap increases. See [Torus Worlds](TORUS-WORLDS.md) for
the certified intrinsic distance model and bounded geometry-only camera cache.

The operational regular Octahedron reuses this same polyhedral presenter, field,
worker and input/history system. Its verified eight-triangle net uses the shared
triangular projection factory; Tetrahedron retains its original net and public
entry points. A geometry-qualified N128/N256 Octahedron profile admits 262,146
canonical samples after actual pixels, memory, input latency and recovery pass.
Other profiles retain their prior cap; work/history/backing limits do not change.
See the [Solid Octahedron review](OCTAHEDRON-SOLID-EDITOR.md).

The existing families have different accepted reconstruction mathematics. This
standard does not silently replace cylinder Hermite reconstruction with cube
bilinear reconstruction, or reinterpret saved geography. A hollow variant uses
its corresponding family's accepted field and shading, rather than choosing a
lower-quality terrain path because excavation geometry is different.

`elevation-colors.ts` is the common CPU palette, including the allocation-free
output form used in the spherical raster. `surface-renderer.ts` defines finite
backing dimensions and display receipts. `raster-quality.ts` supplies bounded
settled density and actual boundary coverage. `excavation-interval-glsl.ts`
shares capsule math and conservative projected cut bounds. GPU programs retain
the accepted terrain functions; geometry adapters select the actual surface.

## Presentation contract

* Canonical elevation arrays remain the authority. Display fields, textures,
  atlases and images are derived, read-only epochs. Viewing cannot write terrain.
* Select the real hit and bank first, reconstruct numerical elevation and
  physical gradients, then apply the accepted palette and shading. Rock bore
  walls come from real excavation geometry. A color mask cannot replace a hole.
* Coast coverage uses the reconstructed signed elevation. Use actual subpixel
  geographical samples at a boundary. Preserve a pixel's center color when its
  subpixel samples all have the same material/coast class; do not blur ordinary
  ramps or alter geography to conceal the sample grid. Cut layers retain
  unchanged accepted terrain and composite only physically changed coverage;
  avoid synchronous readback/recoloring of the underlying atlas during input.
* Match actual backing density, device pixel ratio, numerical detail and camera
  when comparing variants. A large HTML canvas does not prove that its internal
  ray grid has sufficient resolution.
* Retain a coherent responsive image during input. Optional refinement must
  yield, stop while painting or draining accepted work, cancel obsolete epochs,
  and resume when the display is idle. A renderer must never make a gesture wait
  for a complete settled image.
* A new terrain/cut/opposing-bank revision gets a fast current image before idle
  refinement. Annotation-only changes must not trigger a costly identical raster.
* Keep resources bounded and release temporary hit fields after publishing a
  refined image. Preserve accepted context-loss and Canvas fallback behavior.
* Fitted editing, read-only immersive inspection and editable connected maps
  follow the same interaction rules across applicable shapes. Their physical
  projections may differ. Inspection pauses painting and both toolbar and
  keyboard history replay, and returning restores the previous editing state.

The current settled Canvas policy is at most 1.5 million pixels on desktop and
650,000 for coarse-pointer input, within the existing backing-density limits.
These are display budgets, independent of numerical resolution. Keep the proven
interactive budgets; a uniform large raster during painting violates this
contract. GPU backing and ordinary cube atlas limits remain explicitly bounded.

Ordinary cylinder-family terrain updates may retain that settled image while
rerendering conservative dirty rectangles, including periodic copies, through
the same coherent field/color/coverage pass. The bound includes the complete
intrinsic dab and reconstruction stencil. Camera/scene changes, unknown source
revision chains, inspection and cuts use the existing complete raster path.
Do not discard a sharp settled frame merely to enlarge a tiny interactive image.
Optional graphics information queries have a separate error boundary; a debug
renderer probe error must not be reported as a later resource-allocation error.

## Required acceptance evidence

Every new shape or presentation change must provide all of the following:

1. Equivalent solid/hollow geography where applicable: identical canonical
   heights, camera, zoom, appearance, sample detail and backend. Test both 0 m
   and -100 m initial conditions where those differences could obscure a defect.
2. Actual output-pixel comparisons with the accepted renderer or an independent
   geographical reference. Check stable terrain color/relief, coastline and
   silhouette coverage, seams and real hole boundaries. A successful return,
   revision match or nonempty screenshot alone is insufficient.
3. N128/N256 or comparable detail, Canvas and actual WebGL2, fitted editing and
   physical inspection, plus ordinary sustained painting/navigation with
   refinement enabled. Report software fallback honestly.
4. Exact canonical words and object identities before/after viewing, whole-
   gesture Undo/Redo, interruption recovery and strictly versioned Save/Open.
   Keep the existing solid and hollow editor regressions green.
5. Raw visual evidence, ordinary responsiveness observations, bounded resource
   evidence and clear limitations. Separate browser emulation, physical-device
   evidence and owner acceptance.

`tests/atlas-render-parity.spec.ts` is the matched solid/hollow pixel gate.
Its production-renderer fixtures use real Raise arithmetic and the same complete
height authority for each pair. A rear-wall cut enables the physical-cut path
without changing the visible front terrain. `tests/hollow-render-quality.spec.ts`
adds ordinary Atlas workflows with actual holes, both banks, all three views and
read-only history checks. Connection/guide and sustained-paint suites verify
excavation and responsiveness separately.

`pyramid-pixels.spec.ts` and `hollow-pyramid-pixels.spec.ts` compare actual
Canvas/WebGL output against the same canonical field and physical hit reference,
including fitted inside and perspective cavity views. The workflow, navigation,
context-loss and touch suites cover editing and history separately. See the
[Pyramid family review](PYRAMID-FINAL-REVIEW.md) for the final source receipt and
the conditional deferral of pyramid excavation.

The Octahedron family uses that same presentation and field infrastructure,
with the shared triangular projection adapter and a qualified eight-face cache
profile. Its solid and hollow pixel suites compare actual hardware GPU/Canvas
output at N128/N256, including fitted interior and cavity perspective. Workflow
suites cover all twelve physical joins, four-face vertices and held strokes;
see the [solid](OCTAHEDRON-SOLID-EDITOR.md) and
[hollow](OCTAHEDRON-HOLLOW-EDITOR.md) reviews and their frozen-source receipts.
The Octahedron cache qualification does not raise limits for unknown geometries.

Ringworld reuses the accepted Open Cylinder boundary, Cylinder Hermite field,
palette, relief, GLSL and coherent Canvas updates. Its qualified geometry-only
hit cache retains one camera epoch, at most 25 bytes per center pixel within
the existing desktop/coarse raster budgets; fractional rays remain live.
Physical dirty rectangles include the intrinsic footprint and complete two-cell
reconstruction stencil in each affected chart. Partial updates use the same
crease/coast coverage quadrature as full output, with a one-pixel label halo.
Neither this cache nor the Ringworld terrain profile raises shared work, history,
backing or queue limits. See the [Ringworld final review](RINGWORLD-FINAL-REVIEW.md)
and its separate foundation, operational and final frozen receipts.

Pixel parity allows the existing bounded raster footprint and minor numeric
channel rounding at edges; it cannot be used to excuse missing material, shifted
geography, visibly lower display resolution or an unresponsive editor. Review
the actual captures as well as numeric thresholds. A proposed replacement must
document why the accepted mechanism failed and provide comparative evidence.

This gate applies to Open Cylinder, any later authorized solid/hollow pyramids,
tetrahedra, polyhedra, tori, ringworlds, fragmented/irregular worlds and subsequent
Atlas geometries. No future geometry is authorized merely by appearing here.

Crescent reuses the accepted polyhedral field, physical-gradient stencils,
polygon color atlas, cube palette/relief, four-quarter-pixel GLSL, dirty journals
and ConnectedWorkspace/history/worker systems. Its 252 charts require a real
static-triangle depth adapter rather than the convex uniform-plane presenter;
Canvas orders genuine wall runs and composites the actual cap silhouette.
Coplanar radial strips share gradient regions without changing other families.
A small immutable prism visibility table agrees with the original triangle rays
in 50,400 comparisons and contains no heights or history. Geometry/pixel and
input evidence, unchanged resource caps, supported local distance domains and
separate owner/device acceptance are in the [Crescent final review](CRESCENT-FINAL-REVIEW.md)
and its three independently frozen checkpoint receipts.

Horseshoe binds that same accepted prism field, palette, static-triangle GPU
adapter, ordered Canvas wall runs, silhouettes, journals and Atlas editor
systems through shared prism modules. Crescent compatibility entry points and
physical construction fingerprints remain intact. Coplanar straight-arm strips
share gradient regions; bend facets, beveled lateral pieces and real terminal
faces keep their physical normals. Empty arm gaps remain empty in rendering,
picking and brush distance. Inward-wall focus clears the actual opposite arm.
The exact 228-chart N32/N64 profile qualifies its capacity without raising any
shared limit. Equivalent canonical-height N128/N256 hardware GPU/Canvas pixels,
ordinary painting, held strokes, joins, navigation, input and strict persistence
are recorded in the [Horseshoe final review](HORSESHOE-FINAL-REVIEW.md) and its
separate frozen A/B/C receipts. Owner acceptance and physical-device performance
remain separate from emulated input and technical qualification.

Arc binds those same field, gradient, palette, polygon atlas, prism GPU/Canvas,
journal, worker, history and Atlas mechanisms to a real bounded annular-sector
solid. Its 244-chart n32/n64 capacity qualification is exact and provider/version
specific. Upper/underside geography, inner/outer boundaries and both closed
terminal faces retain their actual geometry and independent canonical words.
Nearby terminal faces never become longitudinal periodic neighbors. Optional
geometry-supplied distance lower bounds must be conservative certificates; they
do not replace the shared intrinsic-distance authority or relax work limits.

For very thin/sheared prism atlas clips, the already-constructed exact physical
union also supplies the final Canvas mask. Reuse its existing path/scratch layer;
keep internal coverage opaque and constrain antialias color to real material.
Do not expand geometry, change geography or introduce an invisible backing shape
to hide a clip defect. Equivalent-height default N128/N256 and short/near-closed
Arc pixel evidence, native painting/navigation and strict persistence are recorded
in the [Arc final review](ARC-FINAL-REVIEW.md) and separately frozen checkpoint
receipts. Owner acceptance and physical-device performance remain separate.


Hourglass shares the accepted Dumbbell axial builder, bounded certified distance
and pointer-route machinery, welded Float32 authority, indexed field, palette,
relief, triangle GPU, high-quality polygon atlases and ConnectedWorkspace
systems. Its distinct four-segment flares, positive-length waist and two closed
planar caps define its physical geometry. Exact projected convex-region masks
compose actual material coverage; narrow quarter-ray repairs remain at real
waist joins and vertex stars, with separate map vertex coverage. The original
131,072-pixel repair limit and settled backing budgets remain unchanged.
Default-disabled options preserve Dumbbell's published composition. See the
[Hourglass review](HOURGLASS-WORLDS.md) and its separate frozen receipts for
matched-height pixels, ordinary input, exact geography/history, resource costs
and strict format-40 reconstruction. Owner/device acceptance is separate.

Spiral reuses the accepted prism/triangle field, cube palette and relief,
physical polygon atlases, depth GPU, connected workers/history and Atlas
workspace. Its 64-strip normal-station Archimedean body has two closed ends
and actual empty turn gaps. Geometry adapters supply the real winding metric,
conservative station lower bounds, picking, concave outlines and exact polygon
boundary gutters. A qualified 516-chart n32/n64 profile retains common work,
history and settled-backing limits. Bounded nearest-boundary quarter samples
refine actual atlas joins and material creases. Their preparation yields in
idle slices and cancels obsolete camera/revision work through an optional
workspace interaction hook; existing providers keep their previous path.
See the [Spiral review](SPIRAL-WORLDS.md) and separately frozen receipts for
actual pixels, painting/navigation, resources, exact geography and format 41.
Technical verification remains separate from owner and physical-device acceptance.

Spiral qualifies reuse of immutable interior metric stencils and cached physical
boundary incidence with exact field-word and gutter-UV comparisons. Its optional
planar visibility pruning retains every vertex that can participate in a shorter
route than a real boundary-walk witness; certified distances remain authoritative.
Local cone and hinge certificates cache only unchanged geometry/source addresses.
The worker uses the accepted single-pending MessageChannel scheduling turn and
canonical ACK gate. GPU painting defers unused Canvas color work; context loss
refreshes from the journal or rebuilds after missing revisions. Canvas composes
the complete dirty filter footprint with the accepted pattern fill, real material
masks and conservative scratch guard. Empty dirty rectangles perform no output
copy. A refinement repaint must retain an unchanged applied camera and picker;
only a real device/transform invalidation blocks picking until coherent output.
A workspace backing clear or resize must invalidate its cached Canvas frame,
including unchanged-size observations and a return from hardware rendering.
Managed Canvas presenters retain their own bounded backing dimensions; generic
overlay allocation must not resize and erase that backing on high-DPI frames.
Existing prism presenters retain their default composition paths.

Nearest physical visibility admits narrow quarter-ray repair bands before the
unchanged pixel cap is applied; hidden turn edges cannot consume that capacity.
Preparation yields within long segments as well as between edges. Matched output
classifies the actual two-source-texel filtering support at real material creases
in source coordinates, including shear. Coplanar station joins are not material
creases. This qualification does not relax independent silhouette, empty-gap,
coverage, internal-seam or stable terrain-color gates.
