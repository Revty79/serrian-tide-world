import {CYLINDRICAL_TERRAIN_FIELD_GLSL,ELEVATION_COLOR_GLSL,CYLINDRICAL_TERRAIN_COLOR_GLSL} from './cylindrical-terrain-glsl.ts';
import {surfaceWebGLContext,surfaceGraphicsInfo,compileSurfaceProgram,createSurfaceTexture,createSurfaceMesh} from './surface-webgl.ts';
import {cutDisplayDimensions} from './raster-quality.ts';
import {HOLLOW_CYLINDER_GLSL} from './hollow-cylinder-glsl.ts';
import {cylinderCutView,type CylinderExcavationDisplay} from './hollow-cylinder-display.ts';
import { cylinderLayout, cylinderCenterInspection, type CylinderView, type CylinderViewport } from './cylindrical-view.ts';
import { CylinderDisplayCache } from './cylindrical-raster.ts';
import { type SurfaceRenderer } from './surface-renderer.ts';
import { dot3 } from '../surfaces/cube-sphere.ts';
import { cylinderDisplayIndex, type CylinderAppearance } from './cylindrical-elevation.ts';
import {projectedCutBounds} from './excavation-projection.ts';

// Display tessellation only: sagitta <= 1-cos(pi/4096) radius units.
// These vertices are reusable reference geometry, never elevation samples.
export const CYLINDER_DISPLAY_SEGMENTS=4096;
const vertex=`#version 300 es
precision highp float;
precision highp int;
layout(location=0) in vec4 point;
uniform vec3 cameraRight,cameraUp,cameraForward,inspectionEye;
uniform vec2 viewport,translation;
uniform float scale,depthExtent;
uniform int mode;
flat out int region;
void main(){region=int(point.w);if(mode==3){gl_Position=vec4(point.xy,0.,1.);return;}if(mode==2){vec3 q=point.xyz-inspectionEye;float z=dot(q,cameraForward),near=.00001,far=depthExtent;gl_Position=vec4(vec2(-dot(q,cameraRight),dot(q,cameraUp))*scale*2./viewport,(far+near)/(far-near)*z-2.*far*near/(far-near),z);return;}vec2 p=mode==0?vec2(dot(point.xyz,cameraRight),dot(point.xyz,cameraUp))-translation:point.xy+translation;gl_Position=vec4(p*scale*2./viewport,mode==0?-dot(point.xyz,cameraForward)/depthExtent:0.,1.);}`;
export const CYLINDER_FRAGMENT_SHADER=`#version 300 es
precision highp float;
precision highp int;
uniform sampler2D sideElevations,startElevations,endElevations;
uniform vec3 cameraForward;
uniform vec3 cameraRight,cameraUp,inspectionEye;
uniform vec2 viewport,translation,backingSize;
uniform float scale;
uniform float h,phase,radiusMeters,lengthMeters,seaLevel,heightScale;
uniform int mode,relief;
flat in int region;
out vec4 outColor;
const float PI=3.141592653589793;
${CYLINDRICAL_TERRAIN_FIELD_GLSL}
${ELEVATION_COLOR_GLSL}
vec3 surfaceField(vec3 p){
 float theta,r,z;
 if(mode==0||mode==2){r=length(p.xy);theta=r==0.?0.:atan(p.y,p.x);z=p.z;}
 else if(region==0){theta=phase+p.x;r=1.;z=p.y;}
 else {float sign=region==1?1.:-1.,center=region==1?-h-1.:h+1.;vec2 local=vec2(p.x,p.y-center);r=length(local);theta=r==0.?0.:phase+atan(local.x,sign*local.y);z=region==1?-h:h;}
 return region==0?field(sideElevations,theta,r,z,true,h,radiusMeters,lengthMeters):region==1?field(startElevations,theta,r,z,false,h,radiusMeters,lengthMeters):field(endElevations,-theta,r,z,false,h,radiusMeters,lengthMeters);
}
${CYLINDRICAL_TERRAIN_COLOR_GLSL}
vec3 referenceAt(vec2 fragment){
 // Recover the analytic reference point. Thin display triangles must not
 // determine geographical coordinates through imprecise varyings/derivatives.
 vec2 screen=(fragment/backingSize*viewport-.5*viewport)/scale;
 if(mode==1)return vec3(screen-translation,0.);
 if(mode==2){vec3 ray=normalize(-cameraRight*screen.x+cameraUp*screen.y+cameraForward);if(region!=0){float z=region==1?-h:h;return inspectionEye+ray*((z-inspectionEye.z)/ray.z);}float a=dot(ray.xy,ray.xy),b=dot(inspectionEye.xy,ray.xy),c=dot(inspectionEye.xy,inspectionEye.xy)-1.,root=sqrt(max(0.,b*b-a*c));float distance=b>=0.?-c/max(b+root,1e-20):(-b+root)/max(a,1e-20);return inspectionEye+ray*distance;}
 vec3 origin=cameraRight*(screen.x+translation.x)+cameraUp*(screen.y+translation.y);
 if(region!=0){float z=region==1?-h:h;return origin+cameraForward*((z-origin.z)/cameraForward.z);}
 float a=dot(cameraForward.xy,cameraForward.xy),b=dot(origin.xy,cameraForward.xy),c=dot(origin.xy,origin.xy)-1.;
 return origin+cameraForward*((-b+sqrt(max(0.,b*b-a*c)))/max(a,1e-20));
}
${HOLLOW_CYLINDER_GLSL}
void main(){
 if(excavationEnabled==1){outColor=cylinderCutRay(gl_FragCoord.xy);return;}
 vec3 p=referenceAt(gl_FragCoord.xy),value=surfaceField(p),rgb=colorAt(value);
 // Actual subpixel elevation classifications, never a blur of palette texels.
 // Derivatives only bound the work; four quadrature rays determine coverage.
 if(abs(value.x-seaLevel/heightScale)<fwidth(value.x)){
  vec3 a=surfaceField(referenceAt(gl_FragCoord.xy+vec2(-.25,-.25))),b=surfaceField(referenceAt(gl_FragCoord.xy+vec2(.25,-.25))),c=surfaceField(referenceAt(gl_FragCoord.xy+vec2(-.25,.25))),d=surfaceField(referenceAt(gl_FragCoord.xy+vec2(.25,.25)));
  // A conservative derivative bound may include a wholly land/water pixel.
  // Filter only actual class coverage; keep ordinary ramps/relief unblurred.
  if(any(notEqual(greaterThan(vec4(a.x,b.x,c.x,d.x),vec4(seaLevel/heightScale)),bvec4(value.x>seaLevel/heightScale))))rgb=(colorAt(a)+colorAt(b)+colorAt(c)+colorAt(d))*.25;
 }
 float theta=region==0?(mode==0||mode==2?atan(p.y,p.x):phase+p.x):0.;
 float facing=region==0?dot(vec2(cos(theta),sin(theta)),cameraForward.xy):(region==2?1.:-1.)*cameraForward.z;
 outColor=vec4(rgb*(mode==1||mode==2?1.:.74+.26*max(0.,facing)),1.);
}`;
// Keep the accepted terrain program free of cut compilation work. The larger
// analytic program is prepared only when a supported cut view is first used.
const BASE_FRAGMENT=CYLINDER_FRAGMENT_SHADER.replace(HOLLOW_CYLINDER_GLSL,'').replace(' if(excavationEnabled==1){outColor=cylinderCutRay(gl_FragCoord.xy);return;}','');
const BASE_UNIFORMS=['sideElevations','startElevations','endElevations','viewport','translation','backingSize','cameraRight','cameraUp','cameraForward','inspectionEye','scale','depthExtent','h','phase','mode','radiusMeters','lengthMeters','seaLevel','heightScale','relief'];
const CUT_UNIFORMS=['oppositeSide','oppositeStart','oppositeEnd','excavationEnabled','cutterCount','selectedInside','inspection','innerRatio','outerHalf','innerHalf','ownRatio','oppositeRadius','oppositeLength','eyePosition','primitiveA[0]','primitiveB[0]'];
function vertices(h:number,map:boolean){
 const data:number[]=[],add=(x:number,y:number,z:number,region:number)=>data.push(x,y,z,region);
 if(map){for(const p of [[-Math.PI,-h],[Math.PI,-h],[Math.PI,h],[-Math.PI,-h],[Math.PI,h],[-Math.PI,h]])add(p[0]!,p[1]!,0,0);}
 for(let i=0;i<CYLINDER_DISPLAY_SEGMENTS;i++){
  const a=i*2*Math.PI/CYLINDER_DISPLAY_SEGMENTS,b=(i+1)*2*Math.PI/CYLINDER_DISPLAY_SEGMENTS,x=Math.cos(a),y=Math.sin(a),xx=Math.cos(b),yy=Math.sin(b);
  if(!map){add(x,y,-h,0);add(xx,yy,-h,0);add(xx,yy,h,0);add(x,y,-h,0);add(xx,yy,h,0);add(x,y,h,0);}
  for(const [region,sign] of [[1,-1],[2,1]] as const){if(map){const center=sign*(h+1);add(0,center,0,region);add(x,y+center,0,region);add(xx,yy+center,0,region);}else{add(0,0,sign*h,region);add(x,y,sign*h,region);add(xx,yy,sign*h,region);}}
 }
 return new Float32Array(data);
}
/** Browser-GPU resources; caller-owned terrain/cache survive failure and device loss. */
export class CylinderWebGLRenderer implements SurfaceRenderer<CylinderView>{
 private excavation?:CylinderExcavationDisplay;private oppositeSource?:CylinderDisplayCache;private oppositeRevision=-1;private uploadedCut=false;
 setExcavation(value?:CylinderExcavationDisplay){this.excavation=value;}
 private gl:WebGL2RenderingContext|null=null;private program?:WebGLProgram;private terrainProgram?:WebGLProgram;private cutProgram?:WebGLProgram;
 private textures:WebGLTexture[]=[];private meshes:{vao:WebGLVertexArrayObject;buffer:WebGLBuffer;count:number}[]=[];
 private uniforms=new Map<string,WebGLUniformLocation>();private uploadedRevision=-1;private disposed=false;private heightScale=1;
 private canvas:HTMLCanvasElement;private cache:CylinderDisplayCache;private invalidate:()=>void;
 readonly statistics={losses:0,recoveries:0,uploads:0,presentations:0,textureBytes:0,geometryBytes:0,antialias:false,reason:'',renderer:''};
 constructor(canvas:HTMLCanvasElement,cache:CylinderDisplayCache,invalidate:()=>void){this.canvas=canvas;this.cache=cache;this.invalidate=invalidate;canvas.addEventListener('webglcontextlost',this.lost);canvas.addEventListener('webglcontextrestored',this.restored);this.initialize();}
 get available(){return !this.disposed&&!!this.program&&!!this.gl&&!this.gl.isContextLost();}
 private lost=(event:Event)=>{event.preventDefault();this.statistics.losses++;this.statistics.reason='Graphics context lost; using CPU fallback.';this.release(false);this.canvas.hidden=true;this.invalidate();};
 private restored=()=>{if(this.disposed)return;this.initialize();if(this.available)this.statistics.recoveries++;this.invalidate();};
 private compileProgram(source:string){return compileSurfaceProgram(this.gl!,vertex,source);}
 private useProgram(cut:boolean){
  if(cut&&!this.cutProgram)this.cutProgram=this.compileProgram(CYLINDER_FRAGMENT_SHADER);
  const next=cut?this.cutProgram!:this.terrainProgram!;
  if(this.program!==next){this.program=next;this.uniforms.clear();for(const name of [...BASE_UNIFORMS,...(cut?CUT_UNIFORMS:[])]){const location=this.gl!.getUniformLocation(next,name);if(location===null)throw Error(`Missing cylinder graphics uniform ${name}`);this.uniforms.set(name,location);}}
  this.gl!.useProgram(next);
 }
 private initialize(){try{
  const gl=surfaceWebGLContext(this.canvas);this.gl=gl;
  const info=surfaceGraphicsInfo(gl);this.statistics.renderer=info.renderer;
  if(info.software)throw Error('Software graphics detected; using bounded CPU fallback.');
  this.terrainProgram=this.compileProgram(BASE_FRAGMENT);this.useProgram(false);
  // R32F is fetched explicitly. Float-linear extensions are not required.
  for(let i=0;i<6;i++){this.textures.push(createSurfaceTexture(gl));}
  const h=this.cache.terrain.metadata.geometry.lengthMeters/this.cache.terrain.metadata.geometry.radiusMeters/2;
  for(const map of [false,true,undefined]){const data=map===undefined?new Float32Array([-1,-1,0,0,3,-1,0,0,-1,3,0,0]):vertices(h,map),mesh=createSurfaceMesh(gl,data);this.meshes.push(mesh);this.statistics.geometryBytes+=data.byteLength;}
  if(gl.getError()!==gl.NO_ERROR)throw Error('Graphics resource allocation failed; using CPU fallback.');
  this.statistics.antialias=!!gl.getContextAttributes()?.antialias;this.statistics.reason='';
 }catch(e){this.statistics.reason=String(e);this.release(true);this.canvas.hidden=true;this.canvas.width=0;}}
 present(view:CylinderView,size:CylinderViewport,appearance:CylinderAppearance='elevation'){
  if(!this.available)throw Error('Graphics renderer unavailable');
  const gl=this.gl!,at=performance.now(),dimensions=cutDisplayDimensions(size,devicePixelRatio||1,cylinderCutView(view,this.excavation)||cylinderCenterInspection(view)),l=cylinderLayout(this.cache.terrain.geometry,view,size);
  if(this.canvas.width!==dimensions.width||this.canvas.height!==dimensions.height){this.canvas.width=dimensions.width;this.canvas.height=dimensions.height;}
  const excavation=this.excavation,enabled=cylinderCutView(view,excavation),opposite=enabled?excavation!.opposite:undefined;
  const resized=performance.now();this.useProgram(enabled);
  const res=this.cache.terrain.metadata.representation.resolution,a=res.angularSamples,z=res.axialCells,p=res.radialCells;
  if(this.uploadedRevision!==this.cache.sourceRevision||this.uploadedCut!==enabled||opposite&&(this.oppositeSource!==opposite||this.oppositeRevision!==opposite.sourceRevision)){
   const elevations=this.cache.elevationSnapshot(),oppositeWords=opposite?.elevationSnapshot();let bytes=0;
   this.heightScale=1;for(const value of elevations)this.heightScale=Math.max(this.heightScale,Math.abs(value));if(oppositeWords)for(const value of oppositeWords)this.heightScale=Math.max(this.heightScale,Math.abs(value));
   for(let region=0;region<3;region++){const rows=(region===0?z:p)+1,data=new Float32Array(a*rows);
    for(let row=0;row<rows;row++)for(let col=0;col<a;col++){
     data[row*a+col]=elevations[cylinderDisplayIndex(this.cache.terrain,region===0?'side':region===1?'cap-start':'cap-end',row,col)]!/this.heightScale;
    }
    gl.activeTexture(gl.TEXTURE0+region);gl.bindTexture(gl.TEXTURE_2D,this.textures[region]!);gl.texImage2D(gl.TEXTURE_2D,0,gl.R32F,a,rows,0,gl.RED,gl.FLOAT,data);bytes+=data.byteLength;
   }
   if(opposite&&oppositeWords){const rr=opposite.terrain.metadata.representation.resolution;for(let region=0;region<3;region++){const rows=(region===0?rr.axialCells:rr.radialCells)+1,data=new Float32Array(rr.angularSamples*rows);for(let row=0;row<rows;row++)for(let col=0;col<rr.angularSamples;col++)data[row*rr.angularSamples+col]=oppositeWords[cylinderDisplayIndex(opposite.terrain,region===0?'side':region===1?'cap-start':'cap-end',row,col)]!/this.heightScale;gl.activeTexture(gl.TEXTURE0+3+region);gl.bindTexture(gl.TEXTURE_2D,this.textures[3+region]!);gl.texImage2D(gl.TEXTURE_2D,0,gl.R32F,rr.angularSamples,rows,0,gl.RED,gl.FLOAT,data);bytes+=data.byteLength;}}
   this.oppositeSource=opposite;this.oppositeRevision=opposite?.sourceRevision??-1;this.uploadedCut=enabled;
   if(gl.getError()!==gl.NO_ERROR)throw Error('Graphics elevation upload failed; using CPU fallback.');
   this.uploadedRevision=this.cache.sourceRevision;this.statistics.textureBytes=Math.max(this.statistics.textureBytes,bytes);this.statistics.uploads++;
  }
  const uploaded=performance.now(),u=(name:string)=>this.uniforms.get(name)!;
  ['sideElevations','startElevations','endElevations'].forEach((name,i)=>{gl.activeTexture(gl.TEXTURE0+i);gl.bindTexture(gl.TEXTURE_2D,this.textures[i]!);gl.uniform1i(u(name),i);});
  if(enabled){gl.uniform1i(u('excavationEnabled'),1);['oppositeSide','oppositeStart','oppositeEnd'].forEach((name,i)=>{gl.activeTexture(gl.TEXTURE0+3+i);gl.bindTexture(gl.TEXTURE_2D,enabled?this.textures[3+i]!:this.textures[i]!);gl.uniform1i(u(name),3+i);});}
  if(enabled){const e=excavation!,m=e.model,a=new Float32Array(48*4),b=new Float32Array(48*4);m.primitives.forEach((p,i)=>{a.set([...p.a,p.radius],4*i);b.set([...p.b,0],4*i);});gl.uniform4fv(u('primitiveA[0]'),a);gl.uniform4fv(u('primitiveB[0]'),b);gl.uniform1i(u('cutterCount'),m.primitives.length);gl.uniform1i(u('selectedInside'),e.role==='interior'?1:0);gl.uniform1i(u('inspection'),cylinderCenterInspection(view)?1:0);gl.uniform1f(u('innerRatio'),m.innerRatio);gl.uniform1f(u('outerHalf'),m.outerHalfLength);gl.uniform1f(u('innerHalf'),m.innerHalfLength);gl.uniform1f(u('ownRatio'),this.cache.terrain.metadata.geometry.radiusMeters/m.radiusMeters);gl.uniform1f(u('oppositeRadius'),opposite!.terrain.metadata.geometry.radiusMeters);gl.uniform1f(u('oppositeLength'),opposite!.terrain.metadata.geometry.lengthMeters);gl.uniform3fv(u('eyePosition'),(view.eyeMeters??[0,0,0]).map(v=>v/m.radiusMeters));}
  gl.uniform1f(u('radiusMeters'),this.cache.terrain.metadata.geometry.radiusMeters);gl.uniform1f(u('lengthMeters'),this.cache.terrain.metadata.geometry.lengthMeters);gl.uniform1f(u('seaLevel'),this.cache.terrain.metadata.seaLevel);gl.uniform1f(u('heightScale'),this.heightScale);gl.uniform1i(u('relief'),appearance==='relief'?1:0);
  gl.uniform2f(u('viewport'),size.width,size.height);gl.uniform2f(u('translation'),view.mode==='map'?view.pan.x:dot3(view.target,view.frame.right),view.mode==='map'?view.pan.y:dot3(view.target,view.frame.up));
  gl.uniform2f(u('backingSize'),dimensions.width,dimensions.height);
  gl.uniform3fv(u('inspectionEye'),(view.eyeMeters??[0,0,0]).map(v=>v/this.cache.terrain.metadata.geometry.radiusMeters));gl.uniform3fv(u('cameraRight'),view.frame.right);gl.uniform3fv(u('cameraUp'),view.frame.up);gl.uniform3fv(u('cameraForward'),view.frame.forward);gl.uniform1f(u('scale'),l.scale);gl.uniform1f(u('h'),l.h);gl.uniform1f(u('phase'),view.phase);gl.uniform1f(u('depthExtent'),cylinderCenterInspection(view)?4*l.h+4:Math.hypot(view.frame.forward[0],view.frame.forward[1])+l.h*Math.abs(view.frame.forward[2])+.01);gl.uniform1i(u('mode'),enabled?3:cylinderCenterInspection(view)?2:view.mode==='map'?1:0);
  gl.viewport(0,0,dimensions.width,dimensions.height);gl.disable(gl.BLEND);gl.disable(gl.CULL_FACE);gl.enable(gl.DEPTH_TEST);gl.depthFunc(gl.LEQUAL);gl.clearColor(0,0,0,0);gl.clear(gl.COLOR_BUFFER_BIT|gl.DEPTH_BUFFER_BIT);
  if(enabled&&!cylinderCenterInspection(view)){
   // Accepted terrain mesh/program first. Excavation replaces only real changed
   // material, preserving the exact ordinary coastline and MSAA everywhere else.
   gl.uniform1i(u('excavationEnabled'),0);gl.uniform1i(u('mode'),0);const base=this.meshes[0]!;gl.bindVertexArray(base.vao);gl.drawArrays(gl.TRIANGLES,0,base.count);
   gl.uniform1i(u('excavationEnabled'),1);gl.uniform1i(u('mode'),3);gl.disable(gl.DEPTH_TEST);
   const ratio=this.cache.terrain.metadata.geometry.radiusMeters/excavation!.model.radiusMeters,tx=dot3(view.target,view.frame.right),ty=dot3(view.target,view.frame.up),bounds=projectedCutBounds(excavation!.model.primitives,size,p=>({x:l.x+(dot3(p,view.frame.right)/ratio-tx)*l.scale,y:l.y-(dot3(p,view.frame.up)/ratio-ty)*l.scale}),l.scale/ratio);
   if(bounds.width&&bounds.height){const x=Math.floor(bounds.x/size.width*dimensions.width),y=Math.floor((size.height-bounds.y-bounds.height)/size.height*dimensions.height),right=Math.ceil((bounds.x+bounds.width)/size.width*dimensions.width),top=Math.ceil((size.height-bounds.y)/size.height*dimensions.height);gl.enable(gl.SCISSOR_TEST);try{gl.scissor(x,y,right-x,top-y);const overlay=this.meshes[2]!;gl.bindVertexArray(overlay.vao);gl.drawArrays(gl.TRIANGLES,0,overlay.count);}finally{gl.disable(gl.SCISSOR_TEST);}}
  }else{const mesh=this.meshes[enabled?2:view.mode==='physical'?0:1]!;gl.bindVertexArray(mesh.vao);gl.drawArrays(gl.TRIANGLES,0,mesh.count);}
  if(gl.isContextLost())throw Error('Graphics context lost during presentation');this.canvas.hidden=false;this.statistics.presentations++;
  return{revision:this.uploadedRevision,...dimensions,resizeMs:resized-at,uploadMs:uploaded-resized,submitMs:performance.now()-uploaded};
 }
 fail(reason:unknown){this.statistics.reason=String(reason);this.release(true);this.canvas.hidden=true;this.canvas.width=0;}
 private release(remove:boolean){const gl=this.gl;if(gl&&remove){for(const t of this.textures)gl.deleteTexture(t);for(const m of this.meshes){gl.deleteVertexArray(m.vao);gl.deleteBuffer(m.buffer);}if(this.terrainProgram)gl.deleteProgram(this.terrainProgram);if(this.cutProgram)gl.deleteProgram(this.cutProgram);}this.textures=[];this.meshes=[];this.program=undefined;this.terrainProgram=undefined;this.cutProgram=undefined;this.uniforms.clear();this.uploadedRevision=-1;this.oppositeSource=undefined;this.oppositeRevision=-1;this.uploadedCut=false;this.statistics.textureBytes=0;this.statistics.geometryBytes=0;}
 dispose(){this.disposed=true;this.canvas.removeEventListener('webglcontextlost',this.lost);this.canvas.removeEventListener('webglcontextrestored',this.restored);this.release(true);this.gl=null;this.canvas.width=0;}
}
