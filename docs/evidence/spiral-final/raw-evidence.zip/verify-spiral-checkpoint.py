﻿import subprocess,json,hashlib,sys
revision=sys.argv[2]if len(sys.argv)>2 else 'HEAD';checkpoint=sys.argv[1];folder={'A':'spiral-foundation','B':'spiral-editor','C':'spiral-final'}[checkpoint]
r=json.loads(subprocess.check_output(['git','show',revision+':docs/evidence/'+folder+'/receipt.json']))
entries={**r['sourceHashes'],**r['artifacts']};data=subprocess.run(['git','cat-file','--batch'],input=''.join(revision+':'+x+'\n'for x in entries).encode(),stdout=subprocess.PIPE,check=True).stdout;at=0
for name,expected in entries.items():
 end=data.index(b'\n',at);header=data[at:end].split();assert len(header)==3,(name,header);size=int(header[2]);b=data[end+1:end+1+size];at=end+size+2
 if b'\0'not in b:b=b.replace(b'\r\n',b'\n')
 assert hashlib.sha256(b).hexdigest()==expected,name
print('Verified committed checkpoint '+checkpoint+' hashes: '+str(len(entries)))
