from pathlib import Path
import subprocess,os,shutil,json,hashlib,re

def run(args,path,env=None):
 print('RUN '+' '.join(args),flush=True)
 with Path(path).open('wb')as f:p=subprocess.run(args,stdout=f,stderr=subprocess.STDOUT,env=env,creationflags=subprocess.BELOW_NORMAL_PRIORITY_CLASS)
 if p.returncode:
  print(Path(path).read_text(encoding='utf-8',errors='replace')[-6500:],flush=True)
  raise SystemExit(p.returncode)
 print('PASS '+path,flush=True)
def hashes(paths):
 result={}
 for file in sorted(set(paths),key=str):
  if not file.is_file():continue
  raw=file.read_bytes()
  if b'\0'not in raw:raw=raw.replace(b'\r\n',b'\n')
  result[file.as_posix()]=hashlib.sha256(raw).hexdigest()
 return result
def dependencies(entries):
 root=Path.cwd();test_root=root/'tests';pending=list(entries);found=set();uncertain=False
 while pending:
  file=pending.pop().resolve()
  if file in found or not file.is_file()or not file.is_relative_to(test_root):continue
  found.add(file)
  for _,value in re.findall(r"(['\"`])([^'\"`\r\n]+\.(?:tsx?|json|css))\1",file.read_text(encoding='utf-8-sig')):
   if '${'in value:
    if '/tests/'in value or value.startswith(('./helpers/','../helpers/','./fixtures/','../fixtures/')):uncertain=True
    continue
   target=root/value.lstrip('/')if value.startswith('/tests/')else file.parent/value if value.startswith('.')else None
   if target is not None and target.resolve().is_relative_to(test_root):pending.append(target)
 if uncertain:found.update(x.resolve()for folder in['tests/helpers','tests/fixtures']for x in Path(folder).rglob('*')if x.is_file())
 return[x.relative_to(root)for x in found]
def browser(name,tests,config='playwright.spiral.config.mjs'):
 runtime=hashes([x for x in Path('src').rglob('*')if not x.name.endswith('.test.ts')]+list(Path('.').glob('playwright*.mjs'))+[Path(x)for x in['package.json','package-lock.json','tsconfig.json','vite.config.ts']])
 actual=[Path(x)for x in tests if x.endswith('.spec.ts')]
 fixtures=hashes(dependencies(actual if actual else list(Path('tests').glob('*.spec.ts'))))
 meta=Path('.local/spiral-c-final-'+name+'-inputs.json');report=Path('.local/spiral-c-final-'+name+'-report.json')
 before={'runtimeHashes':runtime,'testHashes':fixtures}
 if meta.exists()and report.exists():
  prior=json.loads(meta.read_text(encoding='utf-8'));stats=json.loads(report.read_text(encoding='utf-8'))['stats']
  # Older groups conservatively included every fixture. Restrict reuse to the
  # actual transitive literal imports/paths, verifying every used file against
  # its recorded hash. Unrecorded baseline helpers must match frozen B.
  baseline=json.loads(subprocess.check_output(['git','show','ad942a7:docs/evidence/spiral-editor/receipt.json']))['sourceHashes']
  same=prior['runtimeHashes']==runtime and all(prior['testHashes'].get(file,baseline.get(file))==value for file,value in fixtures.items())
  if same and stats['unexpected']==stats['flaky']==stats['skipped']==0 and stats['expected']>0 and re.search(r'\b'+str(stats['expected'])+r' passed\b',Path('.local/spiral-c-final-'+name+'.log').read_text(encoding='utf-8',errors='replace')):
   meta.write_text(json.dumps(before,indent=2)+'\n',encoding='utf-8');print('REUSE unchanged verified dependencies '+name,flush=True);return
 run(['node','node_modules/@playwright/test/cli.js','test','-c',config,*tests,'--workers=1','--retries=0','--max-failures=1'],'.local/spiral-c-final-'+name+'.log',{**os.environ,'SPIRAL_REPORT':str(report)})
 assert hashes(map(Path,runtime))==runtime and hashes(map(Path,fixtures))==fixtures,'Inputs changed during '+name
 meta.write_text(json.dumps(before,indent=2)+'\n',encoding='utf-8')
run(['node','node_modules/typescript/bin/tsc','--noEmit'],'.local/spiral-c-final-typecheck.log')
browser('workflow',['tests/spiral-workflow.spec.ts'])
browser('critical',['tests/spiral-joins.spec.ts','tests/spiral-recovery.spec.ts','tests/spiral-touch.spec.ts'])
browser('desktop',['tests/spiral-isolation.spec.ts','tests/spiral-canvas-incremental.spec.ts','tests/spiral-incremental.spec.ts','tests/spiral-configuration.spec.ts','tests/spiral-connected.spec.ts'])
shutil.copytree('.local/spiral-touch','.local/spiral-desktop-touch',dirs_exist_ok=True)
browser('mobile',[],'playwright.spiral-touch.config.mjs')
shutil.copytree('.local/spiral-touch','.local/spiral-mobile',dirs_exist_ok=True)
browser('pixels',['tests/spiral-pixels.spec.ts','tests/spiral-configuration-pixels.spec.ts'])
browser('navigation',['tests/spiral-navigation.spec.ts'])
browser('regression',[],'playwright.spiral-regression.config.mjs')
files=json.loads(Path('.local/spiral-b-source-files.json').read_text(encoding='utf-8'))
for name in ['src/surfaces/spiral-clearance.test.ts','src/rendering/spiral-field-stencil.test.ts','src/surfaces/spiral-local-certificates.test.ts','src/surfaces/spiral-pruned-routes.test.ts','src/rendering/spiral-filter-support.test.ts']:
 if name not in files:files.append(name)
Path('.local/spiral-c-final-source-files.json').write_text(json.dumps(files,indent=2),encoding='utf-8')
log=Path('.local/spiral-c-final-source.log');log.write_bytes(b'')
for file in files:
 print('SOURCE '+file,flush=True)
 with log.open('ab')as f:p=subprocess.run(['node','--test',file],stdout=f,stderr=subprocess.STDOUT,creationflags=subprocess.BELOW_NORMAL_PRIORITY_CLASS)
 if p.returncode:print(log.read_text(encoding='utf-8',errors='replace')[-6000:],flush=True);raise SystemExit(p.returncode)
print('PASS final targeted source checks',flush=True)
run(['node','node_modules/typescript/bin/tsc','--noEmit'],'.local/spiral-c-final-typecheck.log')
run(['node','node_modules/vite/bin/vite.js','build'],'.local/spiral-c-final-build.log')
print('PASS all final Spiral checks',flush=True)
