from pathlib import Path
import hashlib,json,zipfile,shutil,re
p=Path('docs/evidence/spiral-final');p.mkdir(parents=True,exist_ok=False)
counts={'critical':11,'desktop':26,'mobile':2,'pixels':5,'workflow':4,'navigation':2,'regression':10}
reports={}
for name,count in counts.items():
 report=json.loads(Path(f'.local/spiral-c-final-{name}-report.json').read_text(encoding='utf-8'))
 assert report['stats']['expected']==count and report['stats']['unexpected']==report['stats']['flaky']==report['stats']['skipped']==0,(name,report['stats'])
 reports[name]=report['stats']
 inputs=json.loads(Path(f'.local/spiral-c-final-{name}-inputs.json').read_text(encoding='utf-8'))
 for group in inputs.values():
  for filename,expected in group.items():
   raw=Path(filename).read_bytes()
   if b'\0'not in raw:raw=raw.replace(b'\r\n',b'\n')
   assert hashlib.sha256(raw).hexdigest()==expected,(name,filename)
views=0
for detail,variant in [(128,'default'),(256,'default'),(256,'tight'),(256,'long'),(256,'thin')]:
 proof=json.loads(Path(f'.local/spiral-pixels/n{detail}-{variant}.json').read_text(encoding='utf-8'))
 assert proof['sourceHash']==proof['finalHash']
 views+=len(proof['results'])
 for row in proof['results']:
  assert row['stableMax']<=3 and row['referenceColorMax']<=3
  assert all(row[key]==0 for key in ['coverageViolations','outsideViolations','diagonalViolations','stripSeamViolations'])
assert views==44,views
# Verify the complete native matrix, not just the reporter's green case count.
for detail in [128,256]:
 for backend in ['auto','canvas']:
  w=json.loads(Path(f'.local/spiral-workflow/n{detail}-{backend}.json').read_text(encoding='utf-8'))
  assert len(w['results'])==40
  for row in w['results']:
   stat=row['state']['statistics'];stroke=stat['lastStroke']
   assert stat['failures']==0 and stat['lastTermination']=='complete'
   assert stroke['acceptedPositions']==stroke['processedPositions']==(98 if row['tool']=='Raise' else 14)
   assert stroke['discardedPositions']==0
  assert w['held']['summary']['p95InputToPixels']<100
  actual=json.loads(Path(f'.local/spiral-workflow/n{detail}-{backend}-reopened-output.json').read_text(encoding='utf-8'))
  assert actual['alphaDifferent']==0 and actual['maxDifference']<=3
  assert actual['actualAlphaPixels']==actual['freshAlphaPixels']>0
  admission=json.loads(Path(f'.local/spiral-canvas-incremental/n{detail}-refinement-admission.json').read_text(encoding='utf-8'))
  assert admission['checked']>3 and not admission['invalidated']
for source,name in [('critical','joins-recovery-input'),('source','source'),('typecheck','typecheck'),('build','build'),('desktop','desktop'),('mobile','emulated-mobile'),('pixels','matched-pixels'),('workflow','ordinary-editing'),('navigation','navigation'),('regression','shared-regressions')]:
 raw=Path(f'.local/spiral-c-final-{source}.log').read_text(encoding='utf-8-sig')
 (p/f'{name}.log').write_text('\n'.join(line.rstrip()for line in raw.splitlines()).rstrip()+'\n',encoding='utf-8',newline='\n')
source=Path('.local/spiral-c-final-source.log').read_text(encoding='utf-8')
passed=sum(map(int,re.findall(r'(?:#|\u2139) pass (\d+)',source)))
assert passed==195,passed
assert not re.search(r'(?:#|\u2139) fail [1-9]',source)
for variant,pose in [('long','oblique'),('tight','oblique'),('thin','first-end')]:
 shutil.copyfile(f'.local/spiral-pixels/n256-{variant}-{pose}.png',p/f'{variant}-{pose}.png')
artifacts=[]
for folder,patterns in [
 ('spiral-diagnostics',['*.json','*.png']),('spiral-configuration',['*.json','*.png']),('spiral-configuration-measurements',['*.json']),('spiral-connected',['*.json','*.png']),('spiral-isolation',['*.json','*.png']),('spiral-joins',['*.json','*.png']),('spiral-recovery',['*.json','*.png']),('spiral-desktop-touch',['*.json','*.png']),('spiral-mobile',['*.json','*.png']),('spiral-canvas-incremental',['*.json']),('spiral-incremental',['*.json']),
 ('spiral-workflow',['n128-auto.json','n128-canvas.json','n256-auto.json','n256-canvas.json','*-held.json','*-reopened-output.json','*.png']),('spiral-navigation',['*.json','*.png']),
 ('spiral-pixels',['n128-default*','n256-default*','n256-tight*','n256-long*','n256-thin*']),
 ('arc-pilot',['auto.json','canvas.json','auto-painting.json','canvas-painting.json','auto.png','canvas.png']),('arc-pixels',['n256-near-closed*'])]:
 for pattern in patterns:artifacts.extend(Path('.local',folder).glob(pattern))
artifacts.extend(Path('.local').glob('spiral-c-final-*-report.json'));artifacts.extend(Path('.local').glob('spiral-c-final-*-inputs.json'));artifacts.append(Path('.local/spiral-c-final-source-files.json'));artifacts.extend(Path('.local',name)for name in ['run-spiral-final.py','collect-spiral-c.py','verify-spiral-checkpoint.py','spiral-b-source-files.json'])
start=Path('.local/run-spiral-final.py').stat().st_mtime
artifacts.extend(x for x in Path('.local/torus-input').glob('*')if x.is_file()and x.stat().st_mtime>=start)
# Failed development gates remain diagnostic evidence, separate from final passes.
for name in ['spiral-c-before-lazy-desktop.log','spiral-c-before-lazy-desktop-report.json','spiral-c-desktop.log','spiral-c-desktop-report.json','spiral-c-long-gpu.log','spiral-c-long-gpu-report.json','spiral-admission-diagnostic.log','spiral-admission-diagnostic-report.json','spiral-refinement-admission.log','spiral-refinement-admission-report.json']:
 path=Path('.local',name)
 if path.exists():artifacts.append(path)
admission_diagnostic=Path('.local/spiral-workflow/n128-canvas-failed-admission.json')
if admission_diagnostic.exists():artifacts.append(admission_diagnostic)
with zipfile.ZipFile(p/'raw-evidence.zip','w',compression=zipfile.ZIP_DEFLATED,compresslevel=6)as z:
 for f in sorted(set(artifacts),key=str):z.write(f,f.relative_to('.local').as_posix())
assert(p/'raw-evidence.zip').stat().st_size<95*1024**2

def digest(path):
 b=path.read_bytes()
 if b'\0'not in b:b=b.replace(b'\r\n',b'\n')
 return hashlib.sha256(b).hexdigest()
files=sorted([x for x in[*Path('src').rglob('*'),*Path('tests').rglob('*')]if x.is_file()],key=str)+sorted(Path('.').glob('playwright*.mjs'))+[Path(x)for x in['package.json','package-lock.json','tsconfig.json','vite.config.ts','AGENTS.md','docs/ATLAS-RENDERING-STANDARD.md','docs/ATLAS-SHAPES-FIRST-2026-10-23.md','docs/SPIRAL-WORLDS.md']if Path(x).exists()]
r={'checkpoint':'C','baseline':'ad942a7a47ab0e61a32b87ef7f1e3b813b6f2104','startupCheckpoint':'b242082966492875032753ad7d1d76991971bc43','sourceChecks':passed,'browserCoverage':reports,'nativeToolGestures':160,'heldStrokeSeconds':[15,15,15,15],'matchedPixelViews':44,'incrementalCanvasFrames':72,'fullFreshIncrementalViews':6,'actualReopenedOutputComparisons':4,'configurationAndReopenCases':14,'sourceHashes':{x.as_posix():digest(x)for x in files},'artifacts':{x.as_posix():digest(x)for x in p.iterdir()},'claims':'Final Spiral technical qualification; owner visual acceptance and physical device qualification remain separate. Chrome CDP touch and pen are explicitly emulated. Failed development gates in the archive are diagnostic and do not count as final passes.'}
(p/'receipt.json').write_text(json.dumps(r,indent=2)+'\n',encoding='utf-8',newline='\n')
print({'sourceHashes':len(files),'artifacts':len(r['artifacts']),'rawFiles':len(set(artifacts)),'zipBytes':(p/'raw-evidence.zip').stat().st_size})
