import { spawn } from 'node:child_process';
import { writeFile } from 'node:fs/promises';
import { chromium, devices, expect } from '@playwright/test';
import { createWorld, toolsPanel } from '../tests/workspace-helpers.ts';
const records=[];
for(const [label,port,root] of [['before',5186,'.local/a6-p1-baseline'],['after',5187,'.']]) {
  const server=spawn(process.execPath,['node_modules/vite/bin/vite.js',root,'--host','127.0.0.1','--port',String(port),'--strictPort'],{stdio:'ignore',windowsHide:true});
  let browser;
  try {
    let ready=false;for(let i=0;i<200;i++){try{if((await fetch(`http://127.0.0.1:${port}`)).ok){ready=true;break;}}catch{}await new Promise(r=>setTimeout(r,100));}if(!ready)throw Error('Probe server unavailable');
    browser=await chromium.launch();const context=await browser.newContext({...devices['Pixel 7']}),page=await context.newPage(),cdp=await context.newCDPSession(page);
    await context.tracing.start({screenshots:true,snapshots:true,sources:true});await cdp.send('Emulation.setCPUThrottlingRate',{rate:4});await page.goto(`http://127.0.0.1:${port}`);await createWorld(page,'sphere',{n:256,name:'Memory probe'});await toolsPanel(page,false);
    const s=page.viewportSize(),x=s.width/2,y=s.height/2,r=Math.min(s.width,s.height)*.42,c=page.getByRole('img',{name:'Atlas spherical terrain map',exact:true});
    await page.mouse.move(x-.2*r,y);await page.mouse.down();await page.mouse.move(x+.2*r,y,{steps:12});await page.mouse.up();await expect(c).toHaveAttribute('data-processing','false');
    await page.getByRole('button',{name:'Save',exact:true}).click();await expect(page.getByLabel('Map work status',{exact:true})).toHaveText('Saved on this device');
    for(let round=0;round<3;round++){await toolsPanel(page,true);await page.getByRole('button',{name:'Open Map',exact:true}).click();await expect(page.getByLabel('Map work status',{exact:true})).toHaveText('Saved on this device');await toolsPanel(page,false);}
    await page.getByRole('button',{name:'Rotate / Pan',exact:true}).click();await page.mouse.move(x,y);await page.mouse.down();await page.mouse.move(x+.2*r,y+.05*r,{steps:12});await page.mouse.up();
    await page.waitForTimeout(250);const beforeGC=await cdp.send('Runtime.getHeapUsage');await cdp.send('HeapProfiler.collectGarbage');await page.waitForTimeout(100);await cdp.send('HeapProfiler.collectGarbage');
    const afterGC=await cdp.send('Runtime.getHeapUsage'),payload=await page.evaluate(async()=>{const m=await import(new URL('/tests/fixtures/sphere-storage.ts',location.origin).href);return (await m.summary()).payloadSha256;});
    const memory=await c.evaluate(e=>{const d=e.dataset;return {authorityBytes:Number(d.authorityBytes),derivedTexturesAndIndicesBytes:Number(d.cacheBytes),rayCacheBytes:Number(d.rayCacheBytes??0),rasterBytes:Number(d.rasterBytes),sampleCount:Number(d.samples)};});
    records.push({label,beforeGC,afterGC,payload,memory});await context.tracing.stop({path:`docs/evidence/a6-p1-memory-${label}-trace.zip`});await context.close();
  } finally {await browser?.close();server.kill();}
}
if(records[0].payload!==records[1].payload)throw Error('Memory probe geography differs');
await writeFile('docs/evidence/a6-p1-memory.json',JSON.stringify({method:'Sequential separate Chromium Pixel 7 contexts, one browser at a time, 4x CPU throttle, traces on, same actual UI edit and three reopen cycles. Two explicit garbage collections after work, outside all measured timing intervals, inspect retained backing storage. Includes browser/test overhead; not process RSS or physical-device memory.',records},null,2));
console.log(JSON.stringify(records,null,2));
